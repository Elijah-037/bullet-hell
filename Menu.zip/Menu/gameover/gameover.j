document.addEventListener('DOMContentLoaded', function() {
    let selectedOption = 0; // 0 = Restart, 1 = Exit
    const options = document.querySelectorAll('.selectable');
    const arrow = document.getElementById('arrow');

    // Mettre à jour la position de la flèche
    function updateArrow() {
        const selectedDiv = options[selectedOption];

        // Si l'élément sélectionné existe, mettre à jour la position de la flèche
        if (selectedDiv) {
            const rect = selectedDiv.getBoundingClientRect();
            
            // Placer la flèche juste à gauche de l'élément sélectionné
            arrow.style.top = rect.top + rect.height / 2 - 50 + 'px'; // Ajuste verticalement
            arrow.style.left = rect.left - 125 + 'px';  // Placer à gauche de l'image
            arrow.style.display = 'block'; // Afficher la flèche
        }
    }

    // Mettre en surbrillance l'option sélectionnée
    function highlightOption() {
        options.forEach((option, index) => {
            if (index === selectedOption) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });
    }

    // Gérer les événements clavier
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            if (selectedOption === 0) {
                alert('Restart Game');
                // Ajoute ici le code pour redémarrer le jeu
            } else if (selectedOption === 1) {
                alert('Exit Game');
                // Ajoute ici le code pour quitter le jeu
            }
        } else if (e.key === 'ArrowDown') {
            selectedOption = 1; // Sélectionner "Exit"
            highlightOption();
            updateArrow();
        } else if (e.key === 'ArrowUp') {
            selectedOption = 0; // Sélectionner "Restart"
            highlightOption();
            updateArrow();
        }
    });

    // Initialiser l'état au début
    highlightOption();
    updateArrow();
});
